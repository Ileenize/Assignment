var topic1 = document.getElementById('topic')
var comment1 = document.getElementById('cm1')
var comment2 = document.getElementById('cm2')
var text 

topic1 = 0
comment1 = 0
comment2 = 0
console.log("topic", topic1)
console.log("cm1", comment1)
console.log("cm2", comment2)

function PostFunction() {
  text = document.getElementById("text").value  
  if (topic1 == 0) {
    document.getElementById("topic").innerText = text
    topic1 = 1
  }
  else if (comment1 == 0) {
    document.getElementById("cm1").innerText = text
    comment1 = 1
  }
  else if (comment2 == 0){
    document.getElementById("cm2").innerText = text
    comment2 = 1
  }
}

function ClearFunction() {
  document.getElementById("topic").innerText = ""
  document.getElementById("cm1").innerText = ""
  document.getElementById("cm2").innerText = ""
  document.getElementById("text").value = ""
}



