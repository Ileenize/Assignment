window.onload = pageLoad;
var input_regist=[];

function pageLoad(){
    var form = document.getElementById("Register");
    console.log(form);
    form.onsubmit = validateForm;
}

function validateForm(){
    var pass = document.forms["Register"]["password"];
    var repass = document.forms["Register"]["repassword"];
    if(pass.value == repass.value){
        alert("Correct");
    }
    else if(pass.value != repass.value){
        alert("something is wrong");
        return false;
    }
    else{
        alert("something is wrong");
        return false;
    }
}