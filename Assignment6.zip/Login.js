const queryString = window.location.search;
 	console.log(queryString);

 	const urlParams = new URLSearchParams(queryString);
 	const UsernameCon = urlParams.get('username');
	console.log(UsernameCon);
 	const passwordCon = urlParams.get('password');
	
window.onload = loginLoad;
function loginLoad(){
	var form = document.getElementById("login");
 	form.onsubmit = checkLogin;
}

function checkLogin(){
	var username = document.forms["login"]["username"];
    var password = document.forms["login"]["password"];
	if(username.value != UsernameCon || password.value != passwordCon)
	{
		alert("Something is wrong");
        return false;
	}
	else 
	{
		alert("Correct");
	}
}