window.onload = pageLoad;
